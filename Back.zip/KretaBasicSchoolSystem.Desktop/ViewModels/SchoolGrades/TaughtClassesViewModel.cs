﻿using KretaBasicSchoolSystem.Desktop.ViewModels.Base;

namespace KretaBasicSchoolSystem.Desktop.ViewModels.SchoolGrades
{
    public class TaughtClassesViewModel : BaseViewModel
    {
    }
}
