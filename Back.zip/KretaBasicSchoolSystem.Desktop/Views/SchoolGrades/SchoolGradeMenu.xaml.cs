﻿using System.Windows.Controls;


namespace KretaBasicSchoolSystem.Desktop.Views.SchoolGrades
{
    /// <summary>
    /// Interaction logic for SchoolOsztalyzatokMenu.xaml
    /// </summary>
    public partial class SchoolGradeMenu : UserControl
    {
        public SchoolGradeMenu()
        {
            InitializeComponent();
        }
    }
}
